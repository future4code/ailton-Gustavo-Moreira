export const corPrimaria = "#ffe4c4"
export const corFundo = "#dcdcdc"